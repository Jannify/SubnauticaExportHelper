﻿#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using Platform.IO;
using UnityEngine;

namespace Jannify.SubnauticaFixes
{
    [HarmonyPatch(typeof(Shader), nameof(Shader.Find))]
    public static class ShaderFindPatch
    {
        [HarmonyPrefix]
        public static void Prefix(string name, ref bool __runOriginal, ref Shader __result)
        {
            if (ShaderByName.TryGetValue(name, out Shader returnShader))
            {
                __result = returnShader;
                __runOriginal = false;
            }
        }

        public static readonly Dictionary<string, Shader> ShaderByName = new Dictionary<string, Shader>();
        public static readonly Dictionary<string, string> ShaderPathByName= new Dictionary<string, string>();

        [HarmonyPrepare]
        public static void PrepareShaders()
        {
            ShaderByName.Clear();
            ShaderPathByName.Clear();
            string[] quids = UnityEditor.AssetDatabase.FindAssets("t:Shader");
            IEnumerable<string> paths = quids.Select(UnityEditor.AssetDatabase.GUIDToAssetPath);

            List<Shader> shaders = new List<Shader>();

            foreach (string path in paths)
            {
                try
                {
                    Shader shader = UnityEditor.AssetDatabase.LoadAssetAtPath<Shader>(path);
                    shaders.Add(shader);

                    if (!ShaderPathByName.ContainsKey(shader.name))
                    {
                        ShaderPathByName.Add(System.IO.Path.GetFileName(path), path);
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError(ex);
                }
            }

            foreach (Shader asset in shaders)
            {
                if (asset == null)
                {
                    Debug.LogError("Shader-Asset was null");
                    continue;
                }

                if (!ShaderByName.ContainsKey(asset.name))
                {
                    ShaderByName.Add(asset.name, asset);
                }
            }
        }
    }
}
#endif