﻿#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using HarmonyLib;
using Oculus.Newtonsoft.Json;
using UnityEditor;
using UnityEngine;

namespace Jannify.SubnauticaFixes
{
    [InitializeOnLoad]
    public class SubnauticaFixesBootstrapper
    {
        private static Harmony instance;

        static SubnauticaFixesBootstrapper()
        {
            ExecuteHarmony();
            ExecuteShaderChecker();
        }

        private static void ExecuteHarmony()
        {
            if (instance is null)
            {
                instance = new Harmony("Jannify.SubnauticaFixes");
            }

            instance.PatchAll();
        }

        [MenuItem("SubnauticaFixes/Fix Shader")]
        private static void ExecuteShaderChecker()
        {
            MD5 md5 = MD5.Create();
            string jsonPath = Application.dataPath.Replace("Assets", "ShaderBackup\\shaderHashes.json");
            Dictionary<string, byte[]> shaderToHash = JsonConvert.DeserializeObject<Dictionary<string, byte[]>>(File.ReadAllText(jsonPath));

            foreach (KeyValuePair<string, byte[]> keyValue in shaderToHash)
            {
                if (ShaderFindPatch.ShaderPathByName.TryGetValue(keyValue.Key, out string path))
                {
                    byte[] hash;
                    using (FileStream stream = File.OpenRead(path))
                    {
                        hash = md5.ComputeHash(stream);
                    }
                    if (!keyValue.Value.SequenceEqual(hash))
                    {
                        string sourcePath = path.Replace("Assets", "ShaderBackup");
                        File.Copy(sourcePath, path, true);
                    }
                }
            }
        }

        [MenuItem("SubnauticaFixes/Build AssetBundles")]
        private static void BuildAssetBundles()
        {
            BuildPipeline.BuildAssetBundles(Path.Combine(Application.streamingAssetsPath, "AssetBundles"), BuildAssetBundleOptions.None, BuildTarget.StandaloneWindows64);
        }
    }
}
#endif