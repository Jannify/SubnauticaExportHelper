﻿#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using HarmonyLib;
using Oculus.Newtonsoft.Json;
using Sentry;
using UnityEditor;
using UnityEngine;

namespace Jannify.SubnauticaFixes
{
    [InitializeOnLoad]
    public class SubnauticaFixesBootstrapper
    {
        private static Harmony instance;

        static SubnauticaFixesBootstrapper()
        {
            ExecuteHarmony();
            ExecuteShaderChecker();

            if (!File.Exists(Path.Combine(Application.streamingAssetsPath, "AssetBundles", "AssetBundles.manifest")) &&
                EditorUtility.DisplayDialog("Missing AssetBundles", "It seems like AssetBundles were never build. \nDo you want to build them now?", "Yes", "No"))
            {
                BuildAssetBundles();
            }
        }

        private static void ExecuteHarmony()
        {
            if (instance is null)
            {
                instance = new Harmony("Jannify.SubnauticaFixes");
            }
            else
            {
                instance.UnpatchSelf();
            }

            instance.PatchAll();
        }

        [MenuItem("SubnauticaFixes/Fix broken Shader")]
        private static void ExecuteShaderChecker()
        {
            try
            {
                MD5 md5 = MD5.Create();
                string jsonPath = Application.dataPath.Replace("Assets", "ShaderBackup\\shaderHashes.json");
                Dictionary<string, byte[]> shaderToHash = JsonConvert.DeserializeObject<Dictionary<string, byte[]>>(File.ReadAllText(jsonPath));

                for (int i = 0; i < shaderToHash.Count; i++)
                {
                    KeyValuePair<string, byte[]> keyValue = shaderToHash.ElementAt(i);

                    EditorUtility.DisplayProgressBar("Fixing broken shaders", $"Checking {keyValue.Key}", (float)i / shaderToHash.Count);

                    if (ShaderFindPatch.ShaderPathByName.TryGetValue(keyValue.Key, out string path))
                    {
                        byte[] hash;
                        using (FileStream stream = File.OpenRead(path))
                        {
                            hash = md5.ComputeHash(stream);
                        }

                        if (!keyValue.Value.SequenceEqual(hash))
                        {
                            string sourcePath = path.Replace("Assets", "ShaderBackup");
                            File.Copy(sourcePath, path, true);
                        }
                    }
                }
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        [MenuItem("SubnauticaFixes/Build AssetBundles")]
        private static void BuildAssetBundles()
        {
            BuildPipeline.BuildAssetBundles(Path.Combine(Application.streamingAssetsPath, "AssetBundles"), BuildAssetBundleOptions.None, BuildTarget.StandaloneWindows64);
        }
    }
}
#endif
